#!/bin/sh

########################################
# push files to target
#
# how to run in adb shell:
#  > androidshmservice &
#  > jackd -S -v -d opensles -C 0 -P 2 -r 44100 -p 1024 &
#  > jack_simple_client &
########################################

COPY_PATH="."

adb shell mount -o remount,rw /system

adb shell mkdir /data/misc/jack
adb shell mkdir /system/lib/jack

adb push $COPY_PATH/lib/jack/jack_alsa.so /system/lib/jack
adb push $COPY_PATH/lib/jack/jack_dummy.so /system/lib/jack
adb push $COPY_PATH/lib/jack/jack_goldfish.so /system/lib/jack
adb push $COPY_PATH/lib/jack/jack_loopback.so /system/lib/jack
adb push $COPY_PATH/lib/jack/jack_net.so /system/lib/jack
adb push $COPY_PATH/lib/jack/jack_opensles.so /system/lib/jack
adb push $COPY_PATH/lib/jack/netmanager.so /system/lib/jack
adb push $COPY_PATH/lib/jack/profiler.so /system/lib/jack

adb push $COPY_PATH/lib/example_lib.so /system/lib
adb push $COPY_PATH/lib/libasound.so /system/lib
adb push $COPY_PATH/lib/libfluidsynth.so /system/lib
adb push $COPY_PATH/lib/libglib-2.0.so /system/lib
adb push $COPY_PATH/lib/libgthread-2.0.so /system/lib
adb push $COPY_PATH/lib/libjack.so /system/lib
adb push $COPY_PATH/lib/libjackserver.so /system/lib
adb push $COPY_PATH/lib/libjackshm.so /system/lib

adb push $COPY_PATH/bin/androidshmservice /system/bin
adb push $COPY_PATH/bin/shmservicedump /system/bin
adb push $COPY_PATH/bin/shmservicetest /system/bin
adb push $COPY_PATH/bin/jackd /system/bin

adb shell chmod 775 /system/bin/androidshmservice
adb shell chmod 775 /system/bin/shmservicedump
adb shell chmod 775 /system/bin/shmservicetest
adb shell chmod 775 /system/bin/jackd

adb push $COPY_PATH/xbin/jack_alias /system/xbin
adb push $COPY_PATH/xbin/jack_bufsize /system/xbin
adb push $COPY_PATH/xbin/jack_connect /system/xbin
adb push $COPY_PATH/xbin/jack_cpu /system/xbin
adb push $COPY_PATH/xbin/jack_cpu_load /system/xbin
adb push $COPY_PATH/xbin/jack_disconnect /system/xbin
adb push $COPY_PATH/xbin/jack_evmon /system/xbin
adb push $COPY_PATH/xbin/jack_freewheel /system/xbin
adb push $COPY_PATH/xbin/jack_iodelay /system/xbin
adb push $COPY_PATH/xbin/jack_latent_client /system/xbin
adb push $COPY_PATH/xbin/jack_load /system/xbin
adb push $COPY_PATH/xbin/jack_lsp /system/xbin
adb push $COPY_PATH/xbin/jack_metro /system/xbin
adb push $COPY_PATH/xbin/jack_midi_dump /system/xbin
adb push $COPY_PATH/xbin/jack_midi_latency_test /system/xbin
adb push $COPY_PATH/xbin/jack_midiseq /system/xbin
adb push $COPY_PATH/xbin/jack_midisine /system/xbin
adb push $COPY_PATH/xbin/jack_monitor_client /system/xbin
adb push $COPY_PATH/xbin/jack_multiple_metro /system/xbin
adb push $COPY_PATH/xbin/jack_samplerate /system/xbin
adb push $COPY_PATH/xbin/jack_server_control /system/xbin
adb push $COPY_PATH/xbin/jack_session_notify /system/xbin
adb push $COPY_PATH/xbin/jack_showtime /system/xbin
adb push $COPY_PATH/xbin/jack_simple_client /system/xbin
adb push $COPY_PATH/xbin/jack_simple_session_client /system/xbin
adb push $COPY_PATH/xbin/jack_test /system/xbin
adb push $COPY_PATH/xbin/jack_thru /system/xbin
adb push $COPY_PATH/xbin/jack_transport /system/xbin
adb push $COPY_PATH/xbin/jack_unload /system/xbin
adb push $COPY_PATH/xbin/jack_wait /system/xbin
adb push $COPY_PATH/xbin/jack_zombie /system/xbin

adb shell chmod 775 /system/xbin/jack_*

